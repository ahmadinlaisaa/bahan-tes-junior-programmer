<div id="delete-modal" class="modal" style="display: none;">
    <p class="mb-3">Anda yakin akan menghapus produk dengan id <span class="id-produk"></span>?</p>
    <a href="#" rel="modal:close" id="delete-confirm" class="bg-red-600 hover:bg-red-700 px-2 py-1 rounded-md font-medium text-slate-100">Hapus</a>
    <a href="#" rel="modal:close" class="bg-lime-500 hover:bg-lime-600 px-2 py-1 rounded-md font-medium text-gray-900">Close</a>
</div>